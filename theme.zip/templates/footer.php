<footer class="content-info">
  <div class="container">
      <p>Copyright &copy; <?php echo date('Y'); ?> Nick Nak Media | All rights reserved. </p>
  </div>
</footer>
