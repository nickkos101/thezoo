<div class="gray-wrap">

  <!-- Responsive Sidebar Unit -->
  <ins class="adsbygoogle"
       style="display:block"
       data-ad-client="ca-pub-9390819141393668"
       data-ad-slot="6214490507"
       data-ad-format="auto"></ins>
  <script>
  (adsbygoogle = window.adsbygoogle || []).push({});
  </script>

  <?php dynamic_sidebar('sidebar-primary'); ?>
</div>
